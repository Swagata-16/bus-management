from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Register)
admin.site.register(Add_route)
admin.site.register(Add_Bus)
admin.site.register(Book_ticket)
admin.site.register(Passenger)
admin.site.register(Asehi)
